package processgrammar.parser;

public record RuleObject(String leftSide, String rightSide) {
}
