package tree;
import java.util.List;

public record RulesForTree(String leftSide, List<String> rightSide) {
}
