package tree;

public record NonTerminalsToExpand(String symbol, int number) {
}
