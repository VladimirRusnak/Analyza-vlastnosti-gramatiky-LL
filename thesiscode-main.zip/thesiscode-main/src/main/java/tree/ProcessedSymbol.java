package tree;

public record ProcessedSymbol(String symbol, boolean processed) {
}
